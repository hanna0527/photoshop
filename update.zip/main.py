import sys
from PySide6.QtGui import *
from PySide6.QtWidgets import *
from PySide6.QtCore import *
import cv2
import numpy as np
from os import remove

from UImenu import initUI, initMenu
from Layout import layout



class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        initUI(self)
        initMenu(self)
        
        #메인화면 레이아웃
        main_layout = QHBoxLayout()

        self.label1 = QLabel(self) #원본 사진
        self.label2 = QLabel(self) #포토샵 후 사진
        
        widget = QWidget(self)

        layout(self, main_layout, widget) #추가
       
#------------------------------functions-----------------------------------------------#
    def show_flie_dialog(self): #이미지 열기
        self.allHide()
        file_name = QFileDialog.getOpenFileName(self, "이미지 열기", "./photo")
        self.image = cv2.imread(file_name[0]) #파일 경로 0
        h, w, _ = self.image.shape
        bytes_per_line = 3 * w
        image = QImage(
            self.image.data, w, h, bytes_per_line,
             QImage.Format_RGB888
        ).rgbSwapped()
        self.QImg1 = image
        self.orginal = self.QImg1
        pixmap = QPixmap(image)
        self.QImg1Pix = pixmap
        self.label1.setPixmap(pixmap)

    def backtoOri(self): #원본으로 돌아가기
        self.QImg1 = self.orginal
        pixmap = QPixmap(self.QImg1)
        self.label1.setPixmap(pixmap)

    def flipImage(self): #좌우반전
        self.allHide()
        pixmap = QPixmap(self.QImg1)
        image = pixmap.transformed(QTransform().scale(-1, 1))
        self.QImg1 = image
        self.label2.setPixmap(image)
     
    def onZoomIn(self): #확대
        self.allHide()
        self.scale *= 2
        self.resize_image()

    def onZoomOut(self): #축소
        self.allHide()
        self.scale /= 2
        self.resize_image()

    def resize_image(self):
        pixmap = QPixmap(self.QImg1)
        size = pixmap.size()
        scaled_pixmap = pixmap.scaled(self.scale * size)
        self.Qpixmap2 = scaled_pixmap
        self.label2.setPixmap(scaled_pixmap)


    def clear_label(self): #새로고침
        self.allHide()
        self.Qpixmap2 = None
        self.label2.clear()


    def save(self): #저장
        self.allHide()
        filePath, _ = QFileDialog.getSaveFileName(self, "Save Image", "",
                            "PNG(*.png);;JPEG(*.jpg *.jpeg);;All Files(*.*) ")
        if filePath == "":
                return
        self.QImg1.save(filePath)

    def image_use(self): #적용
        self.allHide()
        if (self.Qpixmap2 != None):
            self.QImg1 = self.Qpixmap2
            self.label1.setPixmap(self.QImg1)
            self.label2.clear()

#--------------------------------------------------------------------------
    def rotatePixmap30(self): #회전30
        self.allHide()
        img = QPixmap(self.QImg1)
        pixmap = img.copy()
        self.rotation += 30
        transform = QTransform().rotate(self.rotation)
        pixmap = pixmap.transformed(transform, Qt.SmoothTransformation)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def rotatePixmap45(self): #회전45
        self.allHide()
        img = QPixmap(self.QImg1)
        pixmap = img.copy()
        self.rotation += 45
        transform = QTransform().rotate(self.rotation)
        pixmap = pixmap.transformed(transform, Qt.SmoothTransformation)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def rotatePixmap90(self): #회전90
        self.allHide()
        img = QPixmap(self.QImg1)
        pixmap = img.copy()
        self.rotation += 90
        transform = QTransform().rotate(self.rotation)
        pixmap = pixmap.transformed(transform, Qt.SmoothTransformation)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def rotatePixmap180(self): #회전180
        self.allHide()
        img = QPixmap(self.QImg1)
        pixmap = img.copy()
        self.rotation += 180
        transform = QTransform().rotate(self.rotation)
        pixmap = pixmap.transformed(transform, Qt.SmoothTransformation)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def rotateCustom(self, value): #사용자 정의 회전
        self.mod = "회전"
        self.slider_hide()
        self.dial_show()
        pixmap = QPixmap(self.QImg1)
        self.rotation = value
        transform = QTransform().rotate(self.rotation)
        pixmap = pixmap.transformed(transform, Qt.SmoothTransformation)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)
#--------------------------------------------------------------------------
    def lensDstr(self, value): #렌즈 왜곡
        self.mod = "렌즈왜곡" 
        self.dial_hide()
        self.slider_show()
        
        image = self.Qimg2cv(self.QImg1)
        height, width = image.shape[:2]
        bytes_per_line = 3* width
        
        exp = value  # 볼록지수 1.1~, 오목지수 0.1~1.0
        if (exp == False):
            exp = self.default_L//10
        scale = 1
        mapy, mapx = np.indices((height, width), dtype=np.float32)
        mapx = 2 * mapx / (width-1) - 1
        mapy = 2 * mapy / (height-1) - 1
        r, theta = cv2.cartToPolar(mapx, mapy)  # 직교좌표를 극좌표로 변환시키는
        r[r < scale] = r[r < scale] ** exp
        mapx, mapy = cv2.polarToCart(r, theta)  # 극좌표를 직교좌표로 변환시켜주는 함수
        mapx = ((mapx +  1) * width - 1) / 2
        mapy = ((mapy +  1) * height - 1) / 2
        distorted = cv2.remap(image, mapx, mapy, cv2.INTER_LINEAR)
        image = QImage(
            distorted.data, width, height, bytes_per_line,
            QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def blackWhite(self): #흑백
        self.allHide()
        image = self.Qimg2cv(self.QImg1)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) 
        dst = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB) 
        img = QImage(
            dst.data, image.shape[1], image.shape[0], 3* image.shape[1],
            QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(img)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def invImg(self): #색반전
        self.allHide()
        src = self.Qimg2cv(self.QImg1)
        inv = cv2.bitwise_not(src)
        image = QImage(
            inv.data, src.shape[1], src.shape[0], 3*src.shape[1],
            QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def Qimg2cv(self, img): #Qimage to cv2
        img.save('temp2020101035.png', 'png')
        mat = cv2.imread('temp2020101035.png')
        remove('temp2020101035.png')
        return mat
#--------------------------------------------------------------------------
    def maskImgCir(self): #원마스크
        self.allHide()
        img = self.Qimg2cv(self.QImg1)
        h, w = img.shape[:2]
        mask = np.zeros_like(img)
        cv2.circle(mask, (h//2, h//2), h//3, (255, 255, 255), -1)
        masked = cv2.bitwise_and(img, mask)
        image = QImage(
            masked.data, img.shape[1], img.shape[0], 3*img.shape[1],
            QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def maskImgRect(self): #사각형마스크
        self.allHide()
        img = self.Qimg2cv(self.QImg1)
        h, w = img.shape[:2]
        mask = np.zeros_like(img)
        cv2.rectangle(mask, (w//4, h//4), (3*h//4, 3*w//4), (255, 255, 255), -1)
        masked = cv2.bitwise_and(img, mask)
        image = QImage(
            masked.data, img.shape[1], img.shape[0], 3*img.shape[1],
            QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def maskImgTri(self): #삼각형마스크
        self.allHide()
        img = self.Qimg2cv(self.QImg1) 
        h, w = img.shape[:2]
        mask = np.zeros_like(img)
        pts = [np.array([[w//4, 3*h//4],[3*w//4, 3*h//4],[2*w//4, h//4]])]
        cv2.polylines(mask, pts , isClosed =True, color = (255, 255, 255))
        cv2.fillPoly(mask, pts, color = (255, 255, 255))

        masked = cv2.bitwise_and(img, mask)
        image = QImage(
            masked.data, img.shape[1], img.shape[0], 3*img.shape[1],
            QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)
#--------------------------------------------------------------------------
    def soloSlider(self, value):
        if(self.mod == "렌즈왜곡"): #렌즈 왜곡일 시
            self.lensDstr(value/10)
        elif(self.mod == "블러"):
            self.blur(value)
        elif(self.mod == "가우시안"):
            self.gaussian(value)
        elif(self.mod == "메디안"):
            self.median(value)
        elif(self.mod == "바이레터널"):
            self.bilateral(value)

    def slider_hide(self):
        self.slider.setValue(self.default_L)
        self.slider.hide()
        self.sliderDft.hide()
        self.sliderFin.hide()

    def Bslider_hide(self): #블러 사이드
        self.Bslider.hide()
        self.BsliderDft.hide()
        self.BsliderFin.hide()
    
    def slider_show(self):
        self.slider.show()
        self.sliderDft.show()
        self.sliderFin.show()

    def Bslider_show(self):
        self.Bslider.setValue(0)
        self.Bslider.show()
        self.BsliderDft.show()
        self.BsliderFin.show()
#----------------------------------------------------------------------------
    def clicked_event_default(self):
        if(self.mod == "렌즈왜곡"): self.slider.setValue(self.default_L)
        elif(self.mod == "회전"): self.dial.setValue(self.default_d)
        elif(self.mod == "블러" or "가우시안" or "메디안" or "바이레터럴"): self.Bslider.setValue(0)

    def clicked_event_finish(self):
        if(self.mod == "렌즈왜곡"):
            self.label2.clear()
            self.slider_hide()
            self.mod = 0
        if(self.mod == "회전"):
            self.label2.clear()
            self.dial_hide()
            self.mod = 0
        if(self.mod == "블러" or "가우시안" or "메디안" or "바이레터럴"):
            self.label2.clear()
            self.Bslider_hide()
            self.mod = 0


    def allHide(self):
        self.Bslider_hide()
        self.slider_hide()
        self.dial_hide()
        
#----------------------------------------------------------------------------
    def soloDial(self, value):
        if(self.mod == "회전"): #회전일 시
            self.rotateCustom(value)

    def dial_hide(self):
        self.dial.setValue(self.default_d)
        self.dial.hide()
        self.dialDft.hide()
        self.dialFin.hide()
    
    def dial_show(self):
        self.dial.show()
        self.dialDft.show()
        self.dialFin.show()

#----------------------------------------------------------------------------    
    def blur(self, value): #블러 효과(슬라이더 사용)
        self.allHide()
        self.mod = "블러"
        self.Bslider_show()
        image = self.Qimg2cv(self.QImg1)
        h, w, _ = self.image.shape
        bytes_per_line = 3 * w

        b = value
        if (value == False):
            b = 1
        blur = cv2.blur(image, (b, b))
        image = QImage(
            blur, w, h, bytes_per_line,
             QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)


    def gaussian(self, value):
        self.dial_hide()
        self.slider_hide()
        self.mod = "가우시안"
        self.Bslider_show()
        image = self.Qimg2cv(self.QImg1)
        h, w, _ = self.image.shape
        bytes_per_line = 3 * w

        b = value
        if (value == False):
            b = 1
        blur = cv2.GaussianBlur(image, (b, b), 0)
        image = QImage(
            blur, w, h, bytes_per_line,
             QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)

    def median(self, value):
        self.dial_hide()
        self.slider_hide()
        self.mod = "메디안"
        self.Bslider_show()
        image = self.Qimg2cv(self.QImg1)
        h, w, _ = self.image.shape
        bytes_per_line = 3 * w

        b = value
        if (value == False):
            b = 1
        blur = cv2.medianBlur(image, b)
        image = QImage(
            blur, w, h, bytes_per_line,
             QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)   

    def bilateral(self, value):
        self.dial_hide()
        self.slider_hide()
        self.mod = "바이레터럴"
        self.Bslider_show()
        image = self.Qimg2cv(self.QImg1)
        h, w, _ = self.image.shape
        bytes_per_line = 3 * w

        b = value
        if (value == False):
            b = 1
        blur = cv2.bilateralFilter(image, -1, b, b)
        image = QImage(
            blur, w, h, bytes_per_line,
             QImage.Format_RGB888
        ).rgbSwapped()
        pixmap = QPixmap(image)
        self.Qpixmap2 = pixmap
        self.label2.setPixmap(pixmap)       

if __name__ == "__main__":
    app= QApplication()
    window = MainWindow()
    window.show()
    sys.exit(app.exec())