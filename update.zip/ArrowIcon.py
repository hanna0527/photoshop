from PySide6.QtGui import *
from PySide6.QtWidgets import *
from PySide6.QtCore import *

def ArrowIcon(self):
    labelArrow = QLabel("center")
    labelArrow.setFixedSize(100, 100)
    self.addWidget(labelArrow)
    labelArrow.setPixmap(QPixmap(r"icons/arrow.png"))
    labelArrow.move(50, 200)
    labelArrow.setAlignment(Qt.AlignCenter)
