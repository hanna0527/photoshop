from PySide6.QtGui import *
from PySide6.QtWidgets import *
from PySide6.QtCore import *

def label1(label1, main_layout):
    label1.setFixedSize(640, 480)
    main_layout.addWidget(label1)
    label1.setAlignment(Qt.AlignCenter)

def label2(label2, main_layout):
    label2.setFixedSize(640, 480)
    main_layout.addWidget(label2)
    label2.setAlignment(Qt.AlignCenter)