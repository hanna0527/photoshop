from ArrowIcon import ArrowIcon
from Sidebar import Sidebar1, Sidebar2, Sidebar3, Sidebar4
from label import label1, label2


def layout(self, main_layout, widget):
    Sidebar1(self, main_layout) #사이드바 메뉴버튼 

    Sidebar2(self, main_layout) #커스텀 사이드바
    Sidebar3(self, main_layout) #커스텀 다이얼
    Sidebar4(self, main_layout) #블러링 
    
    label1(self.label1, main_layout)

    ArrowIcon(main_layout) #가운데 화살표

    label2(self.label2, main_layout)

    widget.setLayout(main_layout)
    self.setCentralWidget(widget)