from PySide6.QtGui import *
from PySide6.QtWidgets import *
from PySide6.QtCore import *

def initUI(self): #UI
    self.scale = 1 #zoom
    self.rotation = 0 #spin
    self.mod = 0 #사이드 바
    self.operate = False
  
    self.setWindowTitle("Simple Photoshop")
    self.setWindowIcon(QIcon('icons/phicon.png'))
    self.setGeometry(300, 300, 200, 200)


def initMenu(self):
    self.menu = self.menuBar()
    self.menu_file = self.menu.addMenu("파일") #상단

    Save = QAction("저장" ,self)
    self.menu_file.addAction(Save)
    Save.setShortcut("ctrl+s")
    Save.triggered.connect(self.save)

    exitAction = QAction('나가기', self)
    exitAction.setShortcut("esc")
    self.menu_file.addAction(exitAction)
    exitAction.triggered.connect(qApp.quit)

#-------------------------------------------------------------------------
    self.menu_file = self.menu.addMenu("회전") 

    spin30 = QAction("30°" ,self)
    self.menu_file.addAction(spin30)
    spin30.triggered.connect(self.rotatePixmap30)

    spin45 = QAction("45°" ,self)
    self.menu_file.addAction(spin45)
    spin45.triggered.connect(self.rotatePixmap45)

    spin90 = QAction("90°" ,self)
    self.menu_file.addAction(spin90)
    spin90.triggered.connect(self.rotatePixmap90)

    spin180 = QAction("180°" ,self)
    self.menu_file.addAction(spin180)
    spin180.triggered.connect(self.rotatePixmap180)

    spinCst = QAction("사용자 정의" ,self)
    self.menu_file.addAction(spinCst)
    spinCst.triggered.connect(self.rotateCustom)
#-------------------------------------------------------------------------
    self.menu_file = self.menu.addMenu("효과") 

    lens = QAction("렌즈 왜곡" ,self)
    self.menu_file.addAction(lens)
    lens.triggered.connect(self.lensDstr)
    
    bw = QAction("흑백" ,self)
    self.menu_file.addAction(bw)
    bw.triggered.connect(self.blackWhite)

    inv = QAction("색반전" ,self)
    self.menu_file.addAction(inv)
    inv.triggered.connect(self.invImg)

    sepia = QAction("sepia" ,self)
    self.menu_file.addAction(sepia)
    sepia.triggered.connect(self.sepia)


#-------------------------------------------------------------------------
    self.menu_file = self.menu.addMenu("마스크") 

    maskedCir = QAction("원" ,self)
    self.menu_file.addAction(maskedCir)
    maskedCir.triggered.connect(self.maskImgCir)

    maskedRect = QAction("사각형" ,self)
    self.menu_file.addAction(maskedRect)
    maskedRect.triggered.connect(self.maskImgRect)
    maskedTri = QAction("삼각형" ,self)

    self.menu_file.addAction(maskedTri)
    maskedTri.triggered.connect(self.maskImgTri)
#-------------------------------------------------------------------------
    self.menu_file = self.menu.addMenu("편집") 

    zoomIn = QAction("확대" ,self)
    self.menu_file.addAction(zoomIn)
    zoomIn.triggered.connect(self.onZoomIn)

    zoomOut = QAction("축소" ,self)
    self.menu_file.addAction(zoomOut)
    zoomOut.triggered.connect(self.onZoomOut)

    mirror = QAction("좌우반전" ,self)
    self.menu_file.addAction(mirror)
    mirror.triggered.connect(self.flipImage)
#-------------------------------------------------------------------------
    self.menu_file = self.menu.addMenu("블러링") 

    bluring = QAction("blur" ,self)
    self.menu_file.addAction(bluring)
    bluring.triggered.connect(self.blur)

    Gbluring = QAction("Gaussian" ,self)
    self.menu_file.addAction(Gbluring)
    Gbluring.triggered.connect(self.gaussian)

    Mbluring = QAction("median" ,self)
    self.menu_file.addAction(Mbluring)
    Mbluring.triggered.connect(self.median)

    Bbluring = QAction("bilateral" ,self)
    self.menu_file.addAction(Bbluring)
    Bbluring.triggered.connect(self.bilateral)
#-------------------------------------------------------------------------
    self.menu_file = self.menu.addMenu("경계") 

    roberts = QAction("로버츠 교차 필터" ,self)
    self.menu_file.addAction(roberts)
    roberts.triggered.connect(self.robertsFilter)

    sobel = QAction("소벨 필터" ,self)
    self.menu_file.addAction(sobel)
    sobel.triggered.connect(self.sobelFilter)


