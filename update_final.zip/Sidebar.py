from PySide6.QtGui import *
from PySide6.QtWidgets import *
from PySide6.QtCore import *

def Sidebar1(mainwindow, main_layout): #사이드1: 간편메뉴
    sidebar1 = QVBoxLayout()
    button1 = QPushButton("이미지 열기")
    button2 = QPushButton("새로고침")
    button3 = QPushButton("적용")
    button4 = QPushButton("처음 상태로")
    button5 = QPushButton("저장")

    button1.clicked.connect(mainwindow.show_flie_dialog)
    button2.clicked.connect(mainwindow.clear_label)
    button3.clicked.connect(mainwindow.image_use)
    button4.clicked.connect(mainwindow.backtoOri)
    button5.clicked.connect(mainwindow.save)

    sidebar1.addWidget(button1)
    sidebar1.addWidget(button2)
    sidebar1.addWidget(button3)
    sidebar1.addWidget(button4)
    sidebar1.addWidget(button5)

    main_layout.addLayout(sidebar1)


def Sidebar2(mainwindow, main_layout): #사이드2: 슬라이더
    sidebar2 = QVBoxLayout() 
    mainwindow.slider = QSlider(Qt.Horizontal, mainwindow)
    sidebar2.addWidget(mainwindow.slider)
    mainwindow.side2Min = 1.0 
    mainwindow.side2Max = 19.0
    mainwindow.default_L = (mainwindow.side2Min+mainwindow.side2Max)//2 #렌즈 왜곡 디폴트값
    mainwindow.slider.setRange(mainwindow.side2Min, mainwindow.side2Max)
    mainwindow.slider.setValue(mainwindow.default_L)
    mainwindow.slider.setSingleStep(1)
    mainwindow.slider.valueChanged[int].connect(mainwindow.soloSlider)
        
    mainwindow.sliderDft = QPushButton('Default', mainwindow)
    sidebar2.addWidget(mainwindow.sliderDft)
    mainwindow.sliderDft.clicked.connect(mainwindow.clicked_event_default)

    mainwindow.sliderFin = QPushButton('닫기', mainwindow)
    sidebar2.addWidget(mainwindow.sliderFin)
    mainwindow.sliderFin.clicked.connect(mainwindow.clicked_event_finish)
        
    mainwindow.slider_hide()

    main_layout.addLayout(sidebar2)


def Sidebar3(mainwindow, main_layout): #사이드3: 다이얼
    sidebar3 = QVBoxLayout() 
    mainwindow.dial = QDial(mainwindow)

    sidebar3.addWidget(mainwindow.dial)
    min = 0
    max = 360
    mainwindow.default_d = 0
    mainwindow.dial.setRange(min, max)
    mainwindow.dial.setValue(min)
    mainwindow.dial.setSingleStep(1)
    mainwindow.dial.valueChanged[int].connect(mainwindow.soloDial)
        
    mainwindow.dialDft = QPushButton('Default', mainwindow)
    sidebar3.addWidget(mainwindow.dialDft)
    mainwindow.dialDft.clicked.connect(mainwindow.clicked_event_default)

    mainwindow.dialFin = QPushButton('닫기', mainwindow)
    sidebar3.addWidget(mainwindow.dialFin)
    mainwindow.dialFin.clicked.connect(mainwindow.clicked_event_finish)

    mainwindow.dial_hide()
        
    main_layout.addLayout(sidebar3)

def Sidebar4(mainwindow, main_layout): #사이드4: 블러링 슬라이더
    Sidebar4 = QVBoxLayout() 
    
    mainwindow.Bslider = QSlider(Qt.Horizontal, mainwindow)

    Sidebar4.addWidget(mainwindow.Bslider)
    min = 0
    max = 20
    mainwindow.Bslider.setRange(min, max)
    mainwindow.Bslider.setValue(1)
    mainwindow.Bslider.setSingleStep(1)
    mainwindow.Bslider.valueChanged[int].connect(mainwindow.soloSlider)
        
    mainwindow.BsliderDft = QPushButton('Default', mainwindow)
    Sidebar4.addWidget(mainwindow.BsliderDft)
    mainwindow.BsliderDft.clicked.connect(mainwindow.clicked_event_default)

    mainwindow.BsliderFin = QPushButton('닫기', mainwindow)
    Sidebar4.addWidget(mainwindow.BsliderFin)
    mainwindow.BsliderFin.clicked.connect(mainwindow.clicked_event_finish)
        
    mainwindow.Bslider_hide()

    main_layout.addLayout(Sidebar4)
